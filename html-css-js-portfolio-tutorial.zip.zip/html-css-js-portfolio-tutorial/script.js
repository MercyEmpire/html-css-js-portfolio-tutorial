function toggleMenu() {
    const menu = document.querySelector(".menu-links");
    const icon = document.querySelector(".handburger-icon");
    menu.classList.toggleMenu("open");
    icon.classList.toggleMenu("open");
}      